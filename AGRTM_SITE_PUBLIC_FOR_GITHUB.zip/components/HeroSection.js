export default function HeroSection() {
  const addToken = async () => {
    try {
      await window.ethereum.request({
        method: 'wallet_watchAsset',
        params: {
          type: 'ERC20',
          options: {
            address: '0x0000000000000000000000000000000000000000',
            symbol: 'AGRTM',
            decimals: 18,
            image: '/logo.png'
          }
        }
      });
    } catch (error) {
      console.error('Erro ao adicionar o token', error);
    }
  };

  return (
    <section className="flex flex-col justify-center items-center text-center min-h-screen px-4" data-aos="fade-up">
      <h1 className="text-4xl md:text-5xl font-bold mb-4">AGRTM</h1>
      <p className="text-xl md:text-2xl max-w-xl">A Primeira Moeda do Agronegócio no Mundo</p>
      <div className="mt-6 flex gap-4 flex-wrap justify-center">
        <a href="https://metamask.io" target="_blank" rel="noopener noreferrer" className="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700">
          Comprar com MetaMask
        </a>
        <button onClick={addToken} className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700">
          Adicionar AGRTM à MetaMask
        </button>
      </div>
    </section>
  );
}
