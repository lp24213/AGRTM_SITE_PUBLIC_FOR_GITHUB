export default function Footer() {
  return (
    <footer className="p-4 text-center border-t border-gray-800 text-gray-400">
      © 2025 AGRTM - Todos os direitos reservados
    </footer>
  )
}
