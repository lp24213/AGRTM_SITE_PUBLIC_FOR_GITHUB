import Link from 'next/link'

export default function Header() {
  return (
    <header className="flex justify-between items-center p-4 bg-black text-white border-b border-gray-800 sticky top-0 z-50">
      <h1 className="text-xl font-bold">AGRTM</h1>
      <nav className="space-x-4">
        <Link href="/">Home</Link>
        <Link href="/tokenomics">Tokenomics</Link>
        <Link href="/whitepaper">Whitepaper</Link>
        <Link href="/team">Equipe</Link>
        <a href="https://metamask.io" target="_blank" rel="noopener noreferrer" className="bg-green-600 px-4 py-1 rounded hover:bg-green-700">Comprar AGRTM</a>
      </nav>
    </header>
  )
}
