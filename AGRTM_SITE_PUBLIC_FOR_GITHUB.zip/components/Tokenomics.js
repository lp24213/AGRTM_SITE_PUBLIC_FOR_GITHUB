import { Pie } from 'react-chartjs-2'
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js'
ChartJS.register(ArcElement, Tooltip, Legend)

export default function Tokenomics() {
  const data = {
    labels: ['Fundadores', 'Liquidez', 'Investidores', 'Parcerias'],
    datasets: [{
      data: [40, 20, 30, 10],
      backgroundColor: ['#1abc9c', '#3498db', '#9b59b6', '#f39c12'],
      borderWidth: 1
    }]
  }
  return (
    <div className="max-w-xl mx-auto">
      <h2 className="text-2xl font-bold mb-6 text-center">Distribuição de Tokens</h2>
      <Pie data={data} />
    </div>
  )
}
