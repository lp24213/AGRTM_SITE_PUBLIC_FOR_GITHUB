import Head from 'next/head'
import Header from '../components/Header'
import Footer from '../components/Footer'
import ParticlesBackground from '../components/ParticlesBackground'
import HeroSection from '../components/HeroSection'

export default function Home() {
  return (
    <>
      <Head>
        <title>AGRTM | Home</title>
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <Header />
      <main className="bg-black text-white min-h-screen">
      <ParticlesBackground />
        <HeroSection />
      </main>
      <Footer />
    </>
  )
}
