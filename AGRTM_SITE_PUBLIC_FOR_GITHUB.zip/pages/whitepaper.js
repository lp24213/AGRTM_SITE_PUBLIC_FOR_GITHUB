import Head from 'next/head'
import Header from '../components/Header'
import Footer from '../components/Footer'

export default function WhitepaperPage() {
  return (
    <>
      <Head>
        <title>AGRTM | Whitepaper</title>
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <Header />
      <main className="bg-black text-white min-h-screen flex items-center justify-center">
        <a href="/whitepaper.pdf" className="bg-green-600 px-6 py-4 rounded hover:bg-green-700" target="_blank" rel="noopener noreferrer">
          Baixar Whitepaper (PDF)
        </a>
      </main>
      <Footer />
    </>
  )
}
