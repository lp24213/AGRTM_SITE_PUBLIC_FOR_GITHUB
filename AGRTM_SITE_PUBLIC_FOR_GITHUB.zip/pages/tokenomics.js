import Head from 'next/head'
import Header from '../components/Header'
import Footer from '../components/Footer'
import Tokenomics from '../components/Tokenomics'

export default function TokenomicsPage() {
  return (
    <>
      <Head>
        <title>AGRTM | Tokenomics</title>
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <Header />
      <main className="bg-black text-white min-h-screen p-6">
        <Tokenomics />
      </main>
      <Footer />
    </>
  )
}
