import Head from 'next/head'
import Header from '../components/Header'
import Footer from '../components/Footer'

export default function TeamPage() {
  return (
    <>
      <Head><title>AGRTM | Equipe</title></Head>
      <Header />
      <main className="bg-black text-white min-h-screen p-8">
        <h1 className="text-3xl font-bold text-center mb-8">Nossa Equipe</h1>
        <div className="grid md:grid-cols-2 gap-6">
          <div className="p-6 border rounded-lg bg-gray-900">
            <h2 className="text-xl font-bold">Luis Paulo</h2>
            <p className="text-gray-400">Fundador & CEO</p>
          </div>
          <div className="p-6 border rounded-lg bg-gray-900">
            <h2 className="text-xl font-bold">Co-Fundador</h2>
            <p className="text-gray-400">Especialista em blockchain e contratos inteligentes</p>
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}
